#include <iostream>

using namespace std;
int main() {
    float variable = 100.0;
    float* ptr = &variable;
    float* ptr2 = ptr;
    *ptr2 = 200.0;

    cout << "Adress of variable: " << &variable << endl;
    cout << "Znachenie variable: " << variable << endl;
    cout << endl;
    cout << "Adress of ptr: " << ptr << endl;
    cout << "Znachenie, na kotoroye ukazivaet ptr: " << *ptr << endl;

    cout << endl;
    cout << "Adress of ptr2: " << ptr2 << endl;
    cout << "Znachenie, na kotoroye ukazivaet ptr2: " << *ptr2 << endl;

    return 0;
}
