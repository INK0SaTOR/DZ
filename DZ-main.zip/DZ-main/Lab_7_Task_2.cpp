#include <iostream>
using namespace std;
void TrianglePloshad(double* side, double* height) {
    return area = (*side * *height)/2;
}

int main() {
    double side, height, area;

    cout << "Dlinna treugolnika: ";
    cin >> side;
    cout << "Visota treugolnika: ";
    cin >> height;

    TrianglePloshad(&side, &height, &area);

    cout << "Ploshad treugolnika: " << area << endl;

    return 0;
}
